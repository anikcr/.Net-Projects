﻿using System;
using System.Collections.Generic;

namespace ProjectV.Models
{
    public partial class Mark
    {
        public int Id { get; set; }
        public string StudentName { get; set; }
        public int RollNo { get; set; }
        public int Math { get; set; }
        public int English { get; set; }
        public int Bangla { get; set; }
        public int Physics { get; set; }
        public int Chemistry { get; set; }
        public int Biology { get; set; }
        public int Religion { get; set; }
        public int HigherMath { get; set; }
        public int Agriculture { get; set; }
        public int Philosophy { get; set; }
        public int Ict { get; set; }
    }
}
