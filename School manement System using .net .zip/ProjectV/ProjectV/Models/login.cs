﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ProjectV.Models
{
    public class login
    {
        public int Id { get; set; }
        public string email { get; set; }
        public string password { get; set; }
        public string actor_id { get; set; }
    }
}
