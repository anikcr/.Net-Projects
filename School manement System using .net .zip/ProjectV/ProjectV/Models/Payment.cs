﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ProjectV.Models
{
    public class Payment
    {

        public int Id { get; set; }
        public string pyear { get; set; }
        public string pmonth { get; set; }
        public string studentid { get; set; }
        public string rollid{ get; set; }
        public string ammount { get; set; }
       
    }
}

