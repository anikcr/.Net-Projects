﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ProjectV.Models
{
    public class StudentAccount
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Rollno { get; set; }
        public string SClass { get; set; }
        public string Year { get; set; }
        public string Studentid { get; set; }
       
     

    }
}
