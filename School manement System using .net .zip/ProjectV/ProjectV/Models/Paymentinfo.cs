﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace groupa4.Models
{
    public class Paymentinfo
    {
        public int Id { get; set; }
        public string name { get; set; }
        public string roll { get; set; }
        public string rollid { get; set; }
        public int totalammount { get; set; }
        public int Due {get; set; }
    }
}
